# Plan — rentcli deepening — night-2026-09-04

Each section below is self-contained for a single-item implementer session. Verify with
`uv run pytest tests/ -q` and `uv run ruff check rentcli tests` after every item.

## Item: unify-needs-fx-policy

### Problem and why it is worth fixing

`rentcli/application/rescore.py:9-13` defines `_needs_fx(row)` returning
`(row.get(spec.CURRENCY_NATIVE) or "CAD").upper() != "CAD"`, while
`rentcli/application/overrides.py:9-18` defines `_row_needs_fx(row)` which resolves the row's
country pack first and treats a NULL `currency_native` as the pack currency. The overrides
docstring claims it "Mirrors ``rescore._needs_fx``" — it does not: for a non-CA row with NULL
`currency_native`, rescore says no-FX and overrides says FX-needed. Additionally
`rescore.py` (inside `rescore_all`) hardcodes the quote pair
`fx_cache.get_cached_rate(listings_repo.conn, "BRL", "CAD")`, while overrides and
`sync._resolve_pack_fx` (`sync.py:456-459`) resolve the currency from the pack — a third
country pack would be silently skipped by rescore (counted into `skipped_no_fx` forever).

This is a silent-failure split contract that has ALREADY diverged: drift produces no error and
no test failure, only wrong scores. The fix concentrates the FX-eligibility policy in one owner
next to `pack_scoring_params` in `application/_helpers.py`, which already owns the FX read seam
(the `fx_rate_for_scoring` key). Production code deletes more than it adds.

### Ordered steps

1. In `rentcli/application/_helpers.py` (which already imports `pack_for_country` and `spec`),
   add:
   ```python
   def row_needs_fx(row: dict) -> bool:
       """True when the row's rent is stored in a non-CAD currency (§7 truth
       columns). CA rows — and rows predating the currency columns in a CA
       pack — never need conversion. The pack lookup is geographic (the
       row's ``country``), the same resolution sync uses; a non-CA row with
       NULL ``currency_native`` needs conversion at the pack's currency.
       """
       pack = pack_for_country(row.get(spec.COUNTRY))
       if pack.currency == "CAD":
           return False
       return (row.get(spec.CURRENCY_NATIVE) or pack.currency).upper() != "CAD"
   ```
2. In `rentcli/application/overrides.py`: delete the whole `_row_needs_fx` function (lines
   9-18). Replace its two call sites (`if not _row_needs_fx(row):` in `set_override`) with
   `row_needs_fx`; add `row_needs_fx` to the existing
   `from rentcli.application._helpers import parse_and_score` import.
3. In `rentcli/application/rescore.py`: delete `_needs_fx` (lines 9-13). Import `row_needs_fx`
   from `rentcli.application._helpers` and `pack_for_country` from
   `rentcli.infrastructure.country_packs`.
4. In `rescore_all`, replace the hardcoded single-rate line
   `cached_fx = fx_cache.get_cached_rate(listings_repo.conn, "BRL", "CAD")` with a per-quote-currency
   rate map derived from the rows, keeping every other behavior shape (single transaction,
   `skipped_no_fx` accounting, delete-then-rescore-then-meta):
   ```python
   quote_currencies = sorted({
       pack_for_country(r.get(spec.COUNTRY)).currency
       for r in rows if row_needs_fx(r)
   })
   cached_rates = {
       cur: fx_cache.get_cached_rate(listings_repo.conn, cur, "CAD")
       for cur in quote_currencies
   }
   skipped_no_fx = 0
   ```
   In the row loop, replace the `_needs_fx(row) and cached_fx is None` skip and the
   `if cached_fx is not None: payload["fx_rate_for_scoring"] = cached_fx.rate` application with:
   ```python
   rate = cached_rates.get(pack_for_country(row.get(spec.COUNTRY)).currency)
   if row_needs_fx(row) and rate is None:
       skipped_no_fx += 1
       continue
   payload = dict(row)
   if rate is not None:
       payload["fx_rate_for_scoring"] = rate
   ```
   The docstring references to "BRL->CAD" become "quote-currency->CAD".
5. In the post-transaction re-save block (`rescore.py:88-103`), replace `if not _needs_fx(row):`
   with `if not row_needs_fx(row):`.
6. Add a pinning test to `tests/test_override_fx.py` (where the override-side FX contract is
   already tested): a BR row dict with `currency_native=None` and a stubbed cached BRL rate
   asserts that (a) `rescore.row_needs_fx`-driven rescore does NOT count it into
   `skipped_no_fx` when the rate exists and (b) with no cached rate it IS skipped. One test,
   two asserts, using the same fixtures the file already uses for BR rows. If the file's
   fixtures are override-only, put the test in `tests/test_fx_cache.py`'s nearest rescore test
   section instead — do not create a new test file.
7. Delete any now-unused imports (`fx_cache` stays — still used; verify with ruff).

### Files and symbols

- `rentcli/application/_helpers.py` — adds `row_needs_fx`
- `rentcli/application/overrides.py` — deletes `_row_needs_fx`; call sites re-point
- `rentcli/application/rescore.py` — deletes `_needs_fx`; hardcoded `("BRL","CAD")` pair removed;
  rate map per quote currency; loop + re-save block updated
- `tests/test_override_fx.py` (or `tests/test_fx_cache.py`) — one pinning test

### Test strategy

`uv run pytest tests/test_override_fx.py tests/test_fx_cache.py tests/test_country_pack_wiring.py
tests/test_native_stamping.py -q` first, then the full suite + ruff. Existing tests pin the
CA path (bit-identical) and the BR path with `currency_native` set; the new test pins the
unified NULL-`currency_native` BR-row behavior.

### Behavior delta

Not strictly behavior-preserving — say so in the commit message. For every row expressible in
the current DB (NULL `currency_native` only occurs on CA rows) behavior is identical. Two
dormant cases change deliberately: (1) a non-CA row with NULL `currency_native` now takes the
FX path consistently in BOTH rescore and overrides (previously rescore re-scored it at rate
1.0); (2) a second non-CA country pack would now be converted by rescore instead of silently
skipped. Stars, overrides, and stored scores are untouched; `skipped_no_fx` accounting and the
all-or-nothing transaction shape are unchanged.

## Item: fold-needs-detail-into-one-helper

### Problem and why it is worth fixing

`rentcli/application/sync.py` repeats the identical 5-line duck-typed capability probe at three
sites: lines 533-537 (in `_discover_source`, feeding `detail_total` for the progress bar),
lines 617-621 (in the per-source work stage, gating `_refresh_existing_detail_locations`),
and lines 713-717 (in `_fetch_and_merge`, gating the detail fetch). Each site is:

```python
source.needs_detail_fetch()
if hasattr(source, "needs_detail_fetch") and callable(source.needs_detail_fetch)
else not bool(getattr(source, "search_enrichment", False))
```

`BaseSource.needs_detail_fetch()` (`rentcli/infrastructure/sources/base.py:65-67`) already
implements exactly `not bool(getattr(self, "search_enrichment", False))`; sync re-implements
the fallback three times only because test doubles are duck-typed. If the capability contract
changes, discovery's `detail_total` silently diverges from what the refresh/fetch stages
actually do — progress totals mismatch real work or refresh is skipped, with no error and no
test failure. One helper concentrates the contract and deletes more than it adds.

### Ordered steps

1. In `rentcli/application/sync.py`, add a module-level helper next to the other sync helpers
   (above `_discover_source`):
   ```python
   def _needs_detail(source) -> bool:
       """Whether this source's listings need per-listing detail fetches.

       Duck-typed on purpose: test doubles may set ``search_enrichment``
       without inheriting ``BaseSource``.
       """
       if hasattr(source, "needs_detail_fetch") and callable(source.needs_detail_fetch):
           return source.needs_detail_fetch()
       return not bool(getattr(source, "search_enrichment", False))
   ```
2. At site 1 (`_discover_source`, lines 533-537): replace the 5-line conditional expression
   with `needs_detail = _needs_detail(source)`.
3. At site 2 (work stage, lines 617-621): the local variable `_needs_detail` shadows the new
   helper name — replace the whole block with
   `if _needs_detail(source):` directly gating the `_refresh_existing_detail_locations` call
   (the variable is used only in the following `if`).
4. At site 3 (`_fetch_and_merge`, lines 713-718): replace the 5-line block and the
   `if not _needs_detail2:` line with `if not _needs_detail(source): detail = {} else: ...`
   (keep the existing branch bodies byte-identical).
5. Confirm with `grep -n "needs_detail_fetch\|search_enrichment" rentcli/application/sync.py`
   that only the helper body mentions them. Run ruff to catch nothing else broke.

### Files and symbols

- `rentcli/application/sync.py` — adds `_needs_detail`; edits `_discover_source`
  (`needs_detail` assignment), the per-source work stage (`_refresh_existing_detail_locations`
  gate), and `_fetch_and_merge` (`detail` gate)

### Test strategy

`uv run pytest tests/test_source_sync.py tests/test_sync_two_stage.py
tests/test_default_sources_optin.py tests/test_sync_window.py -q`, then full suite + ruff.
`tests/test_source_sync.py::SpySource` sets `search_enrichment` without defining
`needs_detail_fetch` and is the exact duck-typed case the helper must keep working; the
existing discovery/progress tests pin `detail_total` per source kind.

### Behavior delta

Behavior-preserving. Identical logic and evaluation order at all three sites; the only code
motion is the shared helper. No stored state, scores, or user_state touched.

## Item: hoist-source-transport-into-base

### Problem and why it is worth fixing

The single-page HTTP transport seam — lazy `requests.Session`, `fetch_with_retry` with a
source label, and 1-based `page_search_url` — lives only on `FanoutSearchSource`
(`rentcli/infrastructure/sources/base.py:136-178`), so single-URL adapters hand-roll it:

- `chavesnamao.py:160-165` re-implements `fetch` (session init + `fetch_with_retry` +
  `source_label=self.name`), `:167-173` re-implements `page_search_url` with a function-local
  `from ... scrape import with_query_param` import and the module constant `PAGE_PARAM = "pg"`
  (`:59`, used nowhere else), and `:134-135` adds a redundant `__init__` for `_session`.
- `zillow.py:85-89` re-implements `page_search_url` with the `"searchPage"` literal.
- `zillow.py:61-83` inlines session init + `fetch_with_retry` inside its pacing `fetch`
  (the PerimeterX `blocked_check` and city-page spacing are legitimate specialization and stay).

When the fanout transport evolves (retry policy, blocked detection, labels), the copies
silently lag — no error, no test failure. The brand-new CNM adapter re-copying the seam is
fresh proof the contract leaks. Distinct from the SHIPPED `centralize-source-fetch-search-pages`
work: that put the page LOOP (`fetch_search_pages`) on `BaseSource`; this item hoists the
single-page transport the loop drives. Net-negative: the copies (~30 lines) are deleted and one
owner (~22 lines) is added.

### Ordered steps

1. In `rentcli/infrastructure/sources/base.py`, on `BaseSource` add class attributes
   `page_param: str = "page"` and `fetch_label: str = ""`, and three methods:
   ```python
   def _fetch_page(self, url: str, politeness_config: dict) -> str | None:
       if self._session is None:
           self._session = make_session(politeness_config)
       return fetch_with_retry(
           url, politeness_config, self._session,
           source_label=self.fetch_label or self.name,
       )

   def fetch(self, url: str | None, politeness_config: dict) -> str | None:
       if not url:
           return None
       return self._fetch_page(url, politeness_config)

   def page_search_url(self, url: str, page: int) -> str:
       """URL for 1-based ``page`` of a search results URL."""
       if page <= 1:
           return url
       return with_query_param(url, self.page_param, str(page))
   ```
   Move the needed imports (`make_session`, `fetch_with_retry`, `with_query_param` from
   `.scrape`, `requests` for the type annotation) up to `base.py`. `BaseSource` gets the lazy
   session attribute exactly as `_fetch_page` above does (no `__init__` change needed on
   `BaseSource` — subclasses that already define `__init__` keep theirs).
2. In `FanoutSearchSource` (same file): delete `_fetch_page` (lines 167-172) and
   `page_search_url` (lines 174-178) — both are now inherited. KEEP its multi-URL `fetch`
   override (lines 153-165) and `__init__` (session + `_search_urls`), and keep its
   `page_param = "page"` / `fetch_label` declarations as-is (they now specialize the base
   defaults). Its `fetch` body keeps calling `self._fetch_page`.
3. In `rentcli/infrastructure/sources/chavesnamao.py`: set `page_param = "pg"` as a class
   attribute on `ChavesNaMaoSource` (next to `page_size`), delete `PAGE_PARAM` (line 59),
   delete `fetch` (lines 160-165), delete `page_search_url` (lines 167-173), and delete the
   `__init__` (lines 134-135 — the lazy session in `_fetch_page` replaces it). Remove imports
   that become unused (`make_session`, `fetch_with_retry`, `with_query_param` if not used
   elsewhere in the file — let ruff be the arbiter, then double-check with grep).
4. In `rentcli/infrastructure/sources/zillow.py`: set `page_param = "searchPage"` as a class
   attribute, delete `page_search_url` (lines 85-89). KEEP `fetch` (pacing + `blocked_check`
   are legitimate) but replace its inline transport tail — the `if self._session is None: ...
   make_session(...)` plus `html = fetch_with_retry(url, politeness_config, self._session,
   source_label="Zillow", blocked_check=...)` — with a call to
   `fetch_with_retry(url, politeness_config, self._ensure_session(), source_label="Zillow",
   blocked_check=...)` where `_ensure_session` is NOT added; instead keep zillow's session
   init lines exactly as they are (the custom `blocked_check` means zillow does NOT delegate
   to `_fetch_page`). Delete nothing else. Zillow's `__init__` stays.
5. In `rentcli/infrastructure/sources/craigslist.py`: change nothing. Its `fetch` (stateless
   `http.fetch`) and offset-based `page_search_url` (`s=` param) are legitimate overrides.
6. Confirm `kijiji.py` and `livrent.py` (FanoutSearchSource subclasses) need no edits; their
   `page_param`/`fetch_label` values keep winning over the base defaults.

### Files and symbols

- `rentcli/infrastructure/sources/base.py` — `BaseSource` gains `page_param`, `fetch_label`,
  `_fetch_page`, `fetch`, `page_search_url`; `FanoutSearchSource` loses `_fetch_page`,
  `page_search_url`
- `rentcli/infrastructure/sources/chavesnamao.py` — deletes `PAGE_PARAM`, `__init__`, `fetch`,
  `page_search_url`; adds `page_param = "pg"`
- `rentcli/infrastructure/sources/zillow.py` — deletes `page_search_url`; adds
  `page_param = "searchPage"`; `fetch` kept
- `rentcli/infrastructure/sources/craigslist.py`, `kijiji.py`, `livrent.py` — no edits

### Test strategy

`uv run pytest tests/test_source_pagination.py tests/test_chavesnamao_source.py
tests/test_zillow_source.py tests/test_kijiji_source.py tests/test_livrent_source.py
tests/test_source_scrape.py tests/test_polite_loop.py tests/test_na_regression_with_br_source.py
-q`, then full suite + ruff. `test_chavesnamao_source.py:196`
(`test_search_parse_needs_detail_fetch_by_default`) and the pagination tests pin page-URL
shapes per source (`pg`/`searchPage`/`s=offset`); the polite-loop tests pin politeness delays.

### Behavior delta

Behavior-preserving for every existing source: same URLs, same retry/label behavior, same
politeness handling. One deliberate, inert widening: the inherited default `fetch` adds a
`if not url: return None` guard for chavesnamao (the `fetch_search_pages` driver and the sync
detail path never pass None, so it is unreachable in practice). Zillow's PerimeterX pacing,
craigslist's offset pagination and stateless fetch, and fanout multi-URL joining are all
byte-identical.

## Item: delete-shadow-region-helpers

### Problem and why it is worth fixing

`rentcli/application/local_filter_surface.py` carries two dead functions that duplicate the
live `Region` adapter: `_bbox_clause` (lines 532-545) and `_inside_region` (lines 548-557).
Repo-wide grep over `rentcli/`, `web/`, and `tests/` finds zero callers — only the definitions.
All live pin-radius paths use `Region.bbox_clause` (lines 477-485) and `Region.contains`
(lines 487-493), which are near-identical implementations of the same two-step contract (SQL
bbox prefilter, then exact haversine check). The shadow copies are an untested silent trap: a
maintainer who "fixes" radius math in them changes nothing and no test fails — the exact
failure mode the repo already paid to remove once when deleting the dead `apply_filters`
pipeline (shipped 2026-08-17 as `remove-dead-filter-settings-filtering`).

### Ordered steps

1. In `rentcli/application/local_filter_surface.py`, delete `_bbox_clause` (lines 532-545) and
   `_inside_region` (lines 548-557), including their docstrings and the blank lines between
   them.
2. Keep the `math` import and the `haversine_km` import — `Region.bbox_clause` (line 480) and
   `Region.contains` (line 493) still use them. Run ruff to confirm no import went dead.
3. `grep -rn "_bbox_clause\|_inside_region" rentcli/ web/ tests/` must return nothing.

### Files and symbols

- `rentcli/application/local_filter_surface.py` — deletes `_bbox_clause`, `_inside_region`
  (−26 lines; no additions)

### Test strategy

`uv run pytest tests/test_local_filter_surface.py tests/test_search_locations.py -q`, then full
suite + ruff. The Region-based pin tests already pin live behavior; no test referenced the
deleted functions (that is the point).

### Behavior delta

Behavior-preserving — the deleted code was unreachable. Pure deletion, no additions.

## Item: single-home-location-claim-builders

### Problem and why it is worth fixing

The location-claim dict shape — `{"source", "kind", "granularity", **values}` — and the
lat/lon validity guard are built by two byte-identical private copies:

- `_claim`: `rentcli/infrastructure/craigslist_html.py:392-398` ≡
  `rentcli/infrastructure/sources/chavesnamao.py:513-520`
- `_valid_coordinate`: `craigslist_html.py:384-389` ≡ `chavesnamao.py:504-511`

The claim shape is a cross-layer contract: `domain/location.py` (evidence reconciliation,
`same_location_claim`), `application/location_repository.py`, `application/geocoding.py`, and
`infrastructure/db.py` all consume it. When one builder reshapes a field, the other builder
silently produces a different shape and downstream consumers drop the key — no error, no test
failure, and the auditable location-evidence guarantee (CONTEXT.md: "location evidence ...
preserving its provenance") quietly erodes. `domain/location.py` already owns the shape's
meaning, so the builders belong there. Net-negative: two copies (~30 lines with decorators and
docstrings) are deleted, one public owner (~16 lines) is added.

### Ordered steps

1. In `rentcli/domain/location.py`, add to the typing import line `Any` (the file already
   imports `Mapping`, `Iterable` from `typing`). Add two public functions near the evidence
   reconciliation section (before `present_location`), with the exact bodies of the deleted
   copies:
   ```python
   def valid_coordinate(latitude: Any, longitude: Any) -> bool:
       try:
           lat, lon = float(latitude), float(longitude)
       except (TypeError, ValueError):
           return False
       return -90 <= lat <= 90 and -180 <= lon <= 180


   def claim(source: str, kind: str, granularity: str, **values: Any) -> dict:
       """One source's location-evidence claim (see CONTEXT.md: location
       evidence). The single builder for the claim shape every consumer
       reads."""
       return {
           "source": source,
           "kind": kind,
           "granularity": granularity,
           **values,
       }
   ```
2. In `rentcli/infrastructure/craigslist_html.py`: delete `_valid_coordinate` (lines 384-389)
   and `_claim` (lines 392-398); add
   `from rentcli.domain.location import claim, valid_coordinate` and update every call site
   in the file (`_claim(` → `claim(`, `_valid_coordinate(` → `valid_coordinate(` — grep first
   to enumerate them).
3. In `rentcli/infrastructure/sources/chavesnamao.py`: delete the `@staticmethod
   _valid_coordinate` (lines 504-511) and `@staticmethod _claim` (lines 513-520); add the same
   import and update call sites (`self._claim(` / `cls._claim(` → `claim(`,
   `self._valid_coordinate(` / `cls._valid_coordinate(` → `valid_coordinate(`).
4. Grep `rentcli/` for `_claim\b` and `_valid_coordinate\b` to confirm no references remain
   (other modules must not have picked up these private names; if any did, re-point them to
   the domain functions too).
5. Run ruff; it must report no unused imports and no undefined names.

### Files and symbols

- `rentcli/domain/location.py` — adds public `claim`, `valid_coordinate`; `Any` import
- `rentcli/infrastructure/craigslist_html.py` — deletes `_claim`, `_valid_coordinate`;
  call sites re-pointed
- `rentcli/infrastructure/sources/chavesnamao.py` — deletes the two staticmethods; call sites
  re-pointed

### Test strategy

`uv run pytest tests/test_craigslist_html.py tests/test_chavesnamao_source.py
tests/test_location.py tests/test_geocoding.py tests/test_native_stamping.py -q`, then full
suite + ruff. The craigslist coordinate-claim tests and CNM JSON-LD claim tests pin the exact
claim dicts end-to-end through the parsers, so any shape change fails loudly.

### Behavior delta

Behavior-preserving. The builders move; their bodies are byte-identical; claim dicts are
constructed by the same logic. No schema, stored row, or user_state change.
