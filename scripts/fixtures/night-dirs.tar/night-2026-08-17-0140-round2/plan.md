# archloop plan — rentcli night 2026-08-17

## Item: remove-dead-filter-settings-filtering

### Problem and why it is worth fixing

`rentcli/application/filter_settings.py` ships a second, production-dead
implementation of the local row-filtering contract. The live filtering path
is `local_filter_surface.py` (`query_local_surface` / `_matcher` /
`_compute_impact`), which owns the 12 unified fields + 9 rich
parsed-feature filters + region scope. `filter_settings.py` still contains a
separate, older `apply_filters` pipeline (`apply_filters`, `_exclusion_reason`,
`_reason_key`, plus their `_ROW_COLUMNS` and `_UNKNOWN_LABELS` constants and a
`reset_filter_settings` function) that nothing in production calls.

This is a silent-failure split contract: two implementations of the same
"filter rows against user values, first-failing-filter-wins, unknown-data
excludes" semantics. They have ALREADY drifted — `apply_filters` knows nothing
about the rich baths/pics/posted/region/features buckets the surface adds.
Editing `apply_filters` produces no runtime effect and no test failure, so a
future contributor can "fix" the dead path and believe they changed behavior.
`local_filter_surface.py:25` even still claims it "mirrors `apply_filters`" —
a maintenance trap. Removing the dead block removes the ambiguity and ~125
lines of production code plus ~85 lines of dead tests.

### Ordered steps

1. In `rentcli/application/filter_settings.py`, delete:
   - `_ROW_COLUMNS` (lines 43-49)
   - `_UNKNOWN_LABELS` (lines 53-58)
   - `reset_filter_settings` (lines 96-99)
   - the entire `apply_filters` / `_reason_key` / `_exclusion_reason` block
     (lines 153-263), including the `# -- filtering ---` section banner.
2. Delete the dead tests in `tests/test_filter_settings.py`: the section
   header comment at line 181 (`# -- apply_filters ---`) and every test from
   `test_defaults_exclude_below_thresholds` (line 185) to the end of the file
   (line 269), plus the `apply_filters` / `reset_filter_settings` / `_reason_key`
   / `_exclusion_reason` imports at lines 19-22 if they become unused.
3. Update the stale docstring reference in
   `rentcli/application/local_filter_surface.py:25` that says it "mirrors
   `apply_filters`" — replace with a statement that this module owns the
   local-filter contract.
4. Update the module docstring of `filter_settings.py` (lines 9-12) which
   still advertises `apply_filters`; restate that the module owns only
   persistence (`get_filter_settings` / `save_filter_settings`) and
   validation (`parse_and_validate`).
5. Run `uv run ruff check rentcli tests` and `uv run pytest tests/ -q`.

### Exact files and symbols

- `rentcli/application/filter_settings.py` — delete `_ROW_COLUMNS`,
  `_UNKNOWN_LABELS`, `reset_filter_settings`, `apply_filters`, `_reason_key`,
  `_exclusion_reason`; trim module docstring.
- `tests/test_filter_settings.py` — delete the dead `apply_filters` test
  section and its now-unused imports; keep the persistence/validation tests
  (`get_filter_settings`, `save_filter_settings`, `parse_and_validate`,
  `FILTER_KEYS`).
- `rentcli/application/local_filter_surface.py:25` — fix stale docstring
  reference only.

### Test strategy

- Existing `tests/test_filter_settings.py` persistence and validation tests
  must still pass unchanged.
- `tests/test_local_filter_surface.py` must still pass unchanged — it pins
  the live surface contract.
- Full suite: `uv run pytest tests/ -q`. This is deletion-only, so the
  surviving tests are the contract guard.

### Behavior delta

Behavior-preserving. Deleting production-dead code changes no runtime
behavior; the live local-filter path (`local_filter_surface`) is untouched.
Only documentation strings and dead code are removed.

---

## Item: centralize-source-fetch-search-pages

### Problem and why it is worth fixing

The four source adapters each implement an identical `fetch_search_pages`
wrapper that only wires the shared `scrape.fetch_search_pages` driver:

- `rentcli/infrastructure/sources/kijiji.py:73` (~28 lines)
- `rentcli/infrastructure/sources/craigslist.py:42` (~20 lines)
- `rentcli/infrastructure/sources/zillow.py:92` (~22 lines)
- `rentcli/infrastructure/sources/livrent.py:55` (~28 lines)

Each builds `cfg`/`SearchConfig`, builds the search URL, calls the shared
driver with `page_url` / `fetch_page` / `parse_page` callbacks, then (for
kijiji, zillow, livrent) applies `apply_price_filters`. This is a split
contract: the three non-Craigslist adapters run the source-side price
prefilter after the driver, while `craigslist` returns the driver output
directly and never runs `apply_price_filters`. A change to pagination,
dedupe, or price-filter semantics in one adapter silently diverges from the
others, with no test pinning the four equal. Folding the wrappers into one
shared method with per-source hooks concentrates that contract in a single
owner and removes ~60 net lines.

### Ordered steps

1. Add to `rentcli/infrastructure/sources/base.py` a shared
   `fetch_search_pages(self, search, politeness_config, max_pages=1)` method
   on `BaseSource` that:
   - builds `cfg = search or {}` and `search_config = SearchConfig(**cfg) if cfg else None`;
   - computes the base URLs via a `_base_urls_for(search_config)` hook
     (default `[self.build_search_url(search=search_config)]`);
   - returns `None` when the URL list is empty or the first fetch yields nothing;
   - calls `scrape.fetch_search_pages(...)` with
     `page_url=self.page_search_url`,
     `fetch_page=lambda u: self.fetch(u, politeness_config=politeness_config)`,
     `parse_page=self._parse_page`,
     `max_pages`, `page_size=self.page_size`, `source_label=self.name`;
   - returns `apply_price_filters(listings, cfg)`.
   Import `SearchConfig` and `apply_price_filters` into `base.py` as needed.
2. Give each adapter a uniform `_parse_page(html, *, allowed=None)` hook (or
   an `_allowed_for(search_config)` hook) so the shared driver can call it
   without knowing the source's row shape:
   - **kijiji**: keep `_parse_page(html, *, allowed=...)` and `_raw_listings`;
     add `_base_urls_for` returning `[url]`.
   - **zillow**: keep its `_parse_page(html)` (no allowlist); it already
     matches.
   - **livrent**: keep `_parse_page(html, *, allowed=...)`; override
     `_base_urls_for` to return `list(self._search_urls)` (fan-out).
   - **craigslist**: add a thin `_parse_page(html)` that delegates to
     `craigslist_html.parse_search_results(html, search_config=...)`, and
     override the post-process so it does NOT call `apply_price_filters`
     (preserving its current behavior of returning the driver output
     directly).
3. Delete each adapter's `fetch_search_pages` method body in favour of the
   inherited shared method. Remove now-unused imports of
   `fetch_search_pages` / `apply_price_filters` per adapter where they become
   dead.
4. Run `uv run ruff check rentcli tests` and `uv run pytest tests/ -q`.

### Exact files and symbols

- `rentcli/infrastructure/sources/base.py` — add shared `fetch_search_pages`
  and `_base_urls_for` to `BaseSource` (and/or `FanoutSearchSource`).
- `rentcli/infrastructure/sources/kijiji.py:73` — remove local
  `fetch_search_pages`; keep `_parse_page`.
- `rentcli/infrastructure/sources/craigslist.py:42` — remove local
  `fetch_search_pages`; add `_parse_page` wrapper + price-filter-skip hook.
- `rentcli/infrastructure/sources/zillow.py:92` — remove local
  `fetch_search_pages`; keep `_parse_page`.
- `rentcli/infrastructure/sources/livrent.py:55` — remove local
  `fetch_search_pages`; keep `_parse_page`; override `_base_urls_for`.

### Test strategy

- `tests/test_source_pagination.py` pins the pagination/dedupe driver for all
  four sources — must pass unchanged.
- Per-source tests (`tests/test_http.py`, `tests/test_area_mapping.py`, and
  any `test_*_source*` / parse tests) pin each adapter's `parse_search_results`
  / price behavior — must pass unchanged.
- Add/keep a test asserting that `apply_price_filters` is applied for
  kijiji/zillow/livrent and NOT for craigslist, so the split contract is
  explicitly pinned going forward (this is the only new test).
- Full suite: `uv run pytest tests/ -q`.

### Behavior delta

Behavior-preserving for all four adapters. Each source keeps exactly its
current parse path, allowlist handling, fan-out behavior (livrent), and its
current price-filter application (three sources filter, craigslist does not).
The only intentional difference in the diff is the added test pinning that
existing split; no runtime behavior changes.
